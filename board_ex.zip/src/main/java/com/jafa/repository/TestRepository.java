package com.jafa.repository;

public interface TestRepository {
	
	String getDate();
}
